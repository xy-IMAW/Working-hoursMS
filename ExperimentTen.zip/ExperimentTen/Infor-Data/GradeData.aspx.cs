﻿using System;
using System.Collections.Generic;
using FineUI;
using System.Data;
using System.Web.UI.WebControls;
using System.IO;
using System.Web.UI;
using AspNet = System.Web.UI.WebControls;
using System.Data.SqlClient;

namespace WHMS.Infor_Data
{
    public partial class GradeData : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                SessionManager.CheckLogin("../login.aspx");
                BindGrid();
                GridView1.Caption=Session["grade"]+"年级     "+Session["SySe"]+"学期工时表";
            }
        }

        public void Bind(DataTable data)
        {
            // DataTable data = new DataTable();
            DataRow dr;
            //查询该学期工时总表
            string sql1 = "select * from [Working_hoursInfor] where SySe like '%" + Session["SySe"] + "%'";
            //查询该年级学生信息
            string sql2 = "select StuID,StuName,Class from Student where Grade='" + Session["grade"] + "' order by Class,StuID";
            //查询该学期工时信息
            string sql3 = "select distinct Program,Date from [Working_hoursInfor] where SySe like '%" + Session["SySe"] + "%'";
            DataTable dt = Common.datatable(sql1);
            DataTable student = Common.datatable(sql2);
            DataTable program = new DataTable();//活动table
                                                //Common.datatable(sql3);

            data.Columns.Add("学号", typeof(string));//先为输出表添加三列
            data.Columns.Add("姓名", typeof(string));
            data.Columns.Add("班级", typeof(string));

            //构造活动表（存在相同活动不同时间的情况）
            program.Columns.Add("Program", typeof(string));//添加活动名和活动时间列
            program.Columns.Add("Date", typeof(DateTime));

            DataColumn[] key = new DataColumn[] { program.Columns["Date"] };//设置主键
            program.PrimaryKey = key;//设置主键
            int index = 1;//设置相同活动的区分标识
            Common.Open();
            SqlDataReader reader = Common.ExecuteRead(sql3);//获取单行数据
            while (reader.Read())
            {
                string pro = reader.GetString(reader.GetOrdinal("Program"));//获取活动名数据
                string date = reader.GetDateTime(reader.GetOrdinal("Date")).ToString();//获取活动时间数据

                if (program.Rows.Contains(date))
                {
                    pro = pro + index.ToString();
                    index++;
                }
                program.Rows.Add(pro, date);//活动表添加行
            }
            Common.close();//关闭读取流
                           //为输出表添加列
            for (int i = 0; i <= program.Rows.Count; i++)
            {
                if (i < program.Rows.Count)
                {
                    try
                    {
                        data.Columns.Add(program.Rows[i][0].ToString(), typeof(string));//以活动名为列名

                    }
                    catch
                    {
                        data.Columns.Add(program.Rows[i][1].ToString(), typeof(string));//若活动重复则以时间为列名
                    }
                }

                else
                {
                    data.Columns.Add("合计", typeof(int));
                }
            }

            for (int i = 0; i < student.Rows.Count; i++)
            {
                dr = data.NewRow();
                dr[0] = student.Rows[i][0].ToString();
                dr[1] = student.Rows[i][1].ToString();
                dr[2] = student.Rows[i][2].ToString();

                int total = 0;
                for (int j = 0; j < program.Rows.Count; j++)
                {
                    for (int t = 0; t < dt.Rows.Count; t++)
                    {
                        string t1 = dt.Rows[t][0].ToString();
                        string t2 = student.Rows[i][0].ToString();
                        string t3 = dt.Rows[t][2].ToString();
                        string t4 = program.Rows[j][0].ToString();
                        if (dt.Rows[t][0].ToString() == student.Rows[i][0].ToString() && dt.Rows[t][2].ToString() == program.Rows[j][0].ToString()&&program.Rows[j][1].ToString() == dt.Rows[t][5].ToString())
                        {
                            // dr[program.Rows[j][0].ToString()]= dt.Rows[t][3].ToString();
                            dr[3 + j] = dt.Rows[t][3].ToString();
                            total += Convert.ToInt32(dt.Rows[t][3].ToString());
                        }
                    }
                }
                dr["合计"] = total;
                data.Rows.Add(dr);
            }
        }


        private void BindGrid()
        {
            #region  添加动态列   
            /*    GridView1.Columns.Clear();
                 GridView1.Width = new Unit(0);

                 string sql1 = "select * from [Working_hoursInfor] where SySe like '%%'";
                 string sql2 = "select StuID,StuName,Class from Student where Class='' order by Class,StuID";
                 string sql3 = "select distinct Program,Date from [Working_hoursInfor] where SySe like '%%'";
                 DataTable dt = Common.datatable(sql1);                                                                                                                                          
                 DataTable student = Common.datatable(sql2);
                 DataTable program = Common.datatable(sql3);

                 CreateGridColumn("学号", "学号", 150);
                 CreateGridColumn("姓名", "姓名", 150);
                 CreateGridColumn("班级", "班级", 150);


                 for (int i=0;i<=program.Rows.Count;i++)
                 {
                     if (i < program.Rows.Count)
                     {
                   //      DateTime time = Convert.ToDateTime(program.Rows[i][1].ToString()).Date;
                         CreateGridColumn(program.Rows[i][0].ToString(), program.Rows[i][0].ToString(), 150);
                     }
                     else
                     {
                        AspNet. TemplateField count = new AspNet. TemplateField();
                         GridView1.Columns.Add(count);
                     }
                 }*/
            #endregion



            DataTable data = new DataTable();
            Bind(data);
            //dt：数据源  
            GridView1.DataSource = data;
            GridView1.DataBind();
        }

        protected void GridView1_RowCreated(object sender, System.Web.UI.WebControls.GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.Header)
            {
                string sql3 = "select distinct Program,Date from [Working_hoursInfor] where SySe like '%" + Session["SySe"] + "%'";
                DataTable program = new DataTable();
                program.Columns.Add("Program", typeof(string));
                program.Columns.Add("Date", typeof(DateTime));
                DataColumn[] key = new DataColumn[] { program.Columns["Date"] };//设置主键
                program.PrimaryKey = key;
                int index = 1;
                Common.Open();
                SqlDataReader reader = Common.ExecuteRead(sql3);
                while (reader.Read())
                {
                    string pro = reader.GetString(reader.GetOrdinal("Program"));
                    string date = reader.GetDateTime(reader.GetOrdinal("Date")).ToString();
                    while (program.Rows.Contains(date))
                    {
                        pro = pro + index.ToString();
                        index++;
                    }
                    program.Rows.Add(pro, date);
                }

                Common.close();

                TableCellCollection header = e.Row.Cells;

                header.Clear();

                string headtxt = "学号</th><th rowspan='2'>姓名</th>";
                // headtxt += "<th colspan='"+program.Rows.Count+"'></th>";  //跨四列  
                headtxt += "<th rowspan='2'>班级</th>";
                for (int i = 0; i < program.Rows.Count; i++)
                {
                    DateTime Time = Convert.ToDateTime(program.Rows[i][1].ToString());
                    DateTime time = Time.Date;
                    headtxt += "<th>" + time.ToString("yyyy-MM-dd");
                    //  headtxt = headtxt.Substring(0, headtxt.Length - 5);  //移除掉最后一个</th>  
                }
                headtxt += "<th rowspan='2'>合计</th>";
                headtxt += "<tr>";
                for (int i = 0; i < program.Rows.Count; i++)
                {
                    headtxt += "<th>" + program.Rows[i][0].ToString() + "</th>";
                }

                headtxt += "</tr>";

                TableHeaderCell cell = new TableHeaderCell();
                cell.Attributes.Add("rowspan", "2");  //跨两行   
                cell.Text = (headtxt);
                header.Add(cell);

            }
        }

        protected void Button2_Click(object sender, EventArgs e)
        {

            DataTable dt = new DataTable();
            Bind(dt);
            NPOIHelper.ExportByWeb(dt, GridView1.Caption, GridView1.Caption.Trim());

        }


    


    }
}